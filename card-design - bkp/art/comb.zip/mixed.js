// art/mixed.js
// Mixed — per-suit art selection:
//   Radiance → ritual, Void → sigil, Flux → emblem, Aether → emblem
// This variant delegates to the other registered art modules at render time,
// so those modules must be loaded before mixed.js in playtable.html.
(function(){
  const AA = window.AA_ART = window.AA_ART || {};
  AA['mixed'] = {
    name: 'Mixed',
    notes: 'Radiance: ritual · Void: sigil · Flux: emblem · Aether: emblem',
    render: function(elem, cx, cy, artR, e, meta){
      const MAP = {
        radiance: 'ritual',
        void:     'sigil',
        flux:     'emblem',
        aether:   'emblem'
      };
      const key = MAP[elem] || 'sigil';
      const delegate = AA[key];
      if (!delegate) {
        // Fallback: simple bright circle if the delegate hasn't loaded yet
        return '<circle cx="'+cx+'" cy="'+cy+'" r="'+artR+'" fill="none" stroke="'+e.b+'" stroke-width="1" opacity=".5"/>';
      }
      return delegate.render(elem, cx, cy, artR, e, meta);
    }
  };
})();
