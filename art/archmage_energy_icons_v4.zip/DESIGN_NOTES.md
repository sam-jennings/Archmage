# Archmage Ascension Energy Icons v4 — Design Notes

This pass was rebuilt around tabletop icon usability rather than decorative emblem design.

## Applied constraints

1. Silhouette first.
   Each icon should remain distinguishable as a black/white mark at small size.

2. Colour is a reinforcement, not the identifier.
   The four currents still use their established colours, but the monochrome versions remain distinct.

3. One visual verb per current.
   - Radiance: emit
   - Void: absorb
   - Flux: flow/oscillate
   - Aether: bind/stabilise

4. Ornate-minimal balance.
   Each icon has one clear primary shape plus restrained ritual detail. No dense filigree, no tiny texture, no over-detailed interior marks.

5. Symmetry with mnemonic difference.
   The set is visually unified, but each current has a different geometry family:
   - Radiance: ray/corona
   - Void: hollow vortex
   - Flux: crossing wave paths
   - Aether: hexagonal lattice

## Recommended use

Use the colour SVGs on card fronts and player aids.
Use the mono SVGs for rulebook diagrams, accessibility checks, and any future single-colour printing tests.
